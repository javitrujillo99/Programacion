$(function () {
    $("#div1").mouseenter(function () {
        $("body").css("background-color", "red");
    });
});
$(function () {
    $("#div2").mouseenter(function () {
        $("body").css("background-color", "green");
    });
});
$(function () {
    $("#div3").mouseenter(function () {
        $("body").css("background-color", "yellow");
    });
});
$(function () {
    $("#div4").mouseenter(function () {
        $("body").css("background-color", "gray");
    });
});
